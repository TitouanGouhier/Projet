<h1>Compétence</h1>
    	
    		<h3>Informatique</h3>
    			<ul> <li>Assemblage PC</li> <li>Crée une machine virtuelle</li> <li>Faire un dualboot</li> <li>Faire un réseau avec un switch</li> <li>FL STUDIO</li> </ul>
    	
    		<h3>Dévellopement Web</h3>
    			<ul>  <li>Suite Adobe</li> <li>Fondamentale du PHP</li><li>HTML5 et CSS3 <li> Fondamentale du Python </li></ul>
        	